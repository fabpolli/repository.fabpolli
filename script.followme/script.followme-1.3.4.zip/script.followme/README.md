# FollowMe

[Italiano](#italiano) · [English](#english)

---

## Italiano

FollowMe sposta quello che stai guardando o ascoltando su un altro Kodi della rete di casa: la TV di destinazione si accende, la riproduzione continua dallo stesso punto e la TV che lasci si spegne.

### Cosa fa

- **Trasferisce** canali TV e radio PVR, registrazioni, file, playlist (con posizione e ripetizione), modalità party e contenuti di altri addon.
- **Riprende dallo stesso punto**, con un piccolo riavvolgimento regolabile.
- **Accende e spegne le TV tramite CEC** e può eseguire altri comandi, ad esempio per attivare una soundbar.
- **Chiude la riproduzione solo dopo la conferma** della destinazione. Se qualcosa va storto, l'origine riprende a riprodurre e mostra il motivo.
- **Controlla prima di partire** che la destinazione risponda, che abbia gli addon necessari e che possa raggiungere il file. In caso contrario si ferma con un avviso, senza accendere la TV di destinazione.
- **Riporta l'origine alla schermata Home**: ferma la riproduzione, svuota le code e chiude le finestre aperte.
- **Chiede prima di spegnere la TV**: per 10 secondi puoi scegliere "Lascia accesa"; senza risposta la TV si spegne.
- **Adatta i percorsi locali**: su LibreELEC i file locali e le registrazioni di Tvheadend vengono inviati come indirizzo `smb://` dell'origine. I percorsi di rete, come quelli di un NAS, restano invariati.

### Requisiti

- Almeno due dispositivi con Kodi 19 o superiore, nella stessa rete. L'addon è stato provato su Kodi 20 e 21 con LibreELEC.
- TV collegate con HDMI-CEC attivo, se vuoi che si accendano e si spengano da sole.
- La destinazione deve essere accesa e non in sospensione; la sua TV può essere spenta.

### Installazione

Ripeti questi passi su **ogni** Kodi:

1. In *Impostazioni → Sistema → Add-on* attiva **Origini sconosciute**.
2. In *Add-on → Installa da file zip* scegli `script.followme-<versione>.zip`. Installa sempre dallo zip: se copi la cartella a mano, Kodi non carica i testi dell'addon.
3. In *Impostazioni → Servizi → Controllo*:
   - attiva **Consenti il controllo remoto via HTTP** (porta predefinita 8080);
   - imposta nome utente e password;
   - attiva **Consenti il controllo remoto da applicazioni su altri sistemi**.
4. In *Impostazioni → Servizi → Generale* dai al dispositivo un **nome** riconoscibile: compare nelle notifiche.
5. Nelle impostazioni di FollowMe, sezione **Dispositivi di destinazione**, inserisci i dati dell'altro Kodi: nome, IP, porta, utente e password. Puoi configurare fino a tre dispositivi. Conviene assegnare IP fissi dal router.

Il servizio di ricezione parte da solo all'avvio di Kodi.

### Come si usa

Mentre qualcosa è in riproduzione, avvia FollowMe da *Add-on → Add-on programmi*. Con un solo dispositivo configurato il trasferimento parte subito, con più dispositivi FollowMe chiede quale usare.

Per avviarlo con un tasto, crea il file `userdata/keymaps/followme.xml`:

```xml
<keymap>
  <global>
    <remote>
      <green>RunScript(script.followme)</green>
    </remote>
    <keyboard>
      <t mod="ctrl">RunScript(script.followme)</t>
    </keyboard>
  </global>
</keymap>
```

Per attivarlo senza riavviare Kodi, esegui `kodi-send --action=reloadkeymaps`. Il tasto perde la sua funzione predefinita, tranne nelle schermate in cui Kodi lo usa per altro.

Per saltare la scelta del dispositivo: `RunScript(script.followme,target=NomeDispositivo)`.

### Impostazioni

| Sezione | Cosa regola |
|---------|-------------|
| Dispositivi di destinazione | Gli altri Kodi a cui inviare la riproduzione |
| Ricezione | Comandi per accendere la TV, attesa di accensione, comandi aggiuntivi, ripresa dallo stesso punto, riavvolgimento |
| Invio | Pausa durante il trasferimento, arresto locale, attesa massima della destinazione, secondi in cui continuare a riprodurre dopo la conferma, domanda prima dello spegnimento, comandi per spegnere la TV |
| CEC | Comando esterno usato per inviare i frame grezzi |

La TV di destinazione può mostrare l'immagine qualche secondo dopo che Kodi ha confermato la riproduzione. Per evitare un vuoto, aumenta *Invio → Continua a riprodurre qui dopo la conferma*.

### Comandi

I campi "Comandi" accettano una sequenza separata da `;`. Gli indirizzi nei frame sono esempi: sostituiscili con quelli dei tuoi dispositivi.

| Comando | Effetto |
|---------|---------|
| `tv:on` | Accende la TV e la porta sull'ingresso di Kodi |
| `tv:off` | Mette la TV in standby |
| `tv:toggle` | Alterna acceso e spento |
| `wait:1.5` | Attende il numero di secondi indicato |
| `kodi:<builtin>` | Esegue un comando builtin di Kodi |
| `shell:<comando>` | Esegue un comando di sistema |
| `45:70:10:00` | Invia un frame CEC grezzo con il comando esterno della sezione CEC |
| `tx:4F:36` | Invia un frame CEC grezzo tramite `/dev/cec0` (solo Linux) |
| `audio:45:70:10:00` | Chiede l'audio di sistema: attende che il bus CEC sia libero, invia il frame e verifica che l'audio resti attivo, riprovando fino a 50 secondi (solo Linux) |

Com'è fatto un frame, ad esempio `45:70:10:00`:

| Parte | Significato |
|-------|-------------|
| `4` | Indirizzo logico di Kodi, il mittente: può essere 1, 4, 8 o 11 |
| `5` | Indirizzo logico del destinatario, qui il sistema audio (`F` = tutti i dispositivi) |
| `70` | Codice del comando, qui la richiesta di audio di sistema |
| `10:00` | Indirizzo fisico di Kodi, qui 1.0.0.0 |

#### Esempi

Accendere la TV e passare a un ingresso specifico:

```
tv:on; wait:5; 4F:82:20:00
```

Spegnere soundbar e TV. L'attesa serve perché `tv:off` subito dopo lo standby della soundbar può non avere effetto:

```
tx:4F:36; wait:8; tv:off
```

Attivare la soundbar quando arriva un trasferimento. Usa `audio:` invece di un frame con un'attesa fissa: il tempo di risveglio della TV varia, e una richiesta inviata mentre si avvia può lasciare la soundbar accesa ma in mute.

| Impostazione | Valore |
|--------------|--------|
| Ricezione → Attesa accensione TV | `2` |
| Ricezione → Comandi aggiuntivi | `audio:45:70:10:00; wait:2` |
| Invio → Continua a riprodurre qui dopo la conferma | `8` |
| Invio → Comandi per spegnere la TV | `tx:4F:36; wait:8; tv:off` |

Il comando esterno predefinito per i frame grezzi è `echo "tx {frame}" | cec-client -s -d 1`. Disponibilità e sintassi dipendono dal sistema, quindi provalo da SSH prima di usarlo.

### Limiti

- **File**: i percorsi di rete devono funzionare anche sulla destinazione. Per i file locali e le registrazioni, la cartella deve essere condivisa da Samba su LibreELEC e la registrazione deve venire da Tvheadend installato su quel Kodi.
- **Addon**: l'addon deve essere installato, attivo e autenticato anche sulla destinazione. FollowMe verifica installazione e attivazione, ma non l'accesso all'account. Alcuni addon mostrano un proprio dialogo di ripresa o usano link che non funzionano su un altro dispositivo.
- **Canali TV**: la destinazione cerca il canale per ID, nome o numero, quindi deve avere gli stessi canali.
- **Modalità party**: continuano il brano e la coda, ma i brani aggiunti dopo vengono scelti dalla libreria della destinazione e lo storico degli ascolti non viene trasferito.
- **CEC**: su Android i frame grezzi, `tx:` e `audio:` non sono utilizzabili; `tv:on`, `tv:off` e `tv:toggle` restano disponibili. Con adattatori USB Pulse-Eight, `cec-client` può non riuscire ad aprire l'adattatore mentre Kodi lo usa.

### Sicurezza

Kodi salva le impostazioni in chiaro, inclusa la password dell'altro dispositivo, in `userdata/addon_data/script.followme/settings.xml`. Non condividere quel file né i backup che lo contengono.

### Diagnostica

Ogni passaggio viene scritto nel log di Kodi con il prefisso `[script.followme]`. Il log può contenere gli indirizzi dei tuoi dispositivi: controllalo prima di pubblicarlo.

### Licenza

Copyright © 2026 fabpolli

GPL-3.0: il testo completo è in [LICENSE.txt](LICENSE.txt).

---

## English

FollowMe moves whatever you are watching or listening to onto another Kodi on your home network: the destination TV turns on, playback continues from the same point and the TV you leave behind turns off.

### Features

- **Transfers** PVR TV and radio channels, recordings, files, playlists (with position and repeat), party mode and content from other add-ons.
- **Resumes from the same point**, with a small adjustable rewind.
- **Turns TVs on and off via CEC** and can run other commands, for example to activate a soundbar.
- **Stops playback only after the destination confirms.** If something goes wrong, the source resumes playing and shows the reason.
- **Checks before starting** that the destination responds, has the required add-ons and can reach the file. If not, it stops with a notice, without turning on the destination TV.
- **Returns the source to the Home screen**: it stops playback, clears the queues and closes open windows.
- **Asks before turning off the TV**: for 10 seconds you can choose "Leave on"; with no answer, the TV turns off.
- **Adapts local paths**: on LibreELEC, local files and Tvheadend recordings are sent as an `smb://` address on the source. Network paths, such as those on a NAS, are left unchanged.

### Requirements

- At least two devices running Kodi 19 or later on the same network. The add-on has been tested on Kodi 20 and 21 with LibreELEC.
- TVs connected with HDMI-CEC enabled, if you want them to turn on and off automatically.
- The destination must be on and not suspended; its TV can be off.

### Installation

Repeat these steps on **each** Kodi:

1. In *Settings → System → Add-ons*, enable **Unknown sources**.
2. In *Add-ons → Install from zip file*, choose `script.followme-<version>.zip`. Always install from the zip: if you copy the folder by hand, Kodi does not load the add-on's text.
3. In *Settings → Services → Control*:
   - enable **Allow remote control via HTTP** (default port 8080);
   - set a username and password;
   - enable **Allow remote control from applications on other systems**.
4. In *Settings → Services → General*, give the device a recognisable **name**: it appears in notifications.
5. In the FollowMe settings, under **Destination devices**, enter the details of the other Kodi: name, IP, port, username and password. You can configure up to three devices. Assigning fixed IPs from your router is recommended.

The receiving service starts automatically with Kodi.

### Usage

While something is playing, start FollowMe from *Add-ons → Program add-ons*. With one device configured, the transfer starts immediately; with several, FollowMe asks which one to use.

To start it with a key, create the file `userdata/keymaps/followme.xml`:

```xml
<keymap>
  <global>
    <remote>
      <green>RunScript(script.followme)</green>
    </remote>
    <keyboard>
      <t mod="ctrl">RunScript(script.followme)</t>
    </keyboard>
  </global>
</keymap>
```

To activate it without restarting Kodi, run `kodi-send --action=reloadkeymaps`. The key loses its default function, except on screens where Kodi uses it for something else.

To skip the device choice: `RunScript(script.followme,target=DeviceName)`.

### Settings

| Section | What it controls |
|---------|------------------|
| Destination devices | The other Kodi devices playback can be sent to |
| Receiving | Commands to turn on the TV, wait for the TV to turn on, additional commands, resuming from the same position, rewind |
| Sending | Pause while transferring, local stop, maximum wait for the destination, seconds to keep playing after the confirmation, question before turning off, commands to turn off the TV |
| CEC | External command used to send raw frames |

The destination TV may show the picture a few seconds after Kodi confirms playback. To avoid a gap, increase *Sending → Keep playing here after the confirmation*.

### Commands

The "Commands" fields accept a sequence separated by `;`. The addresses in the frames are examples: replace them with those of your own devices.

| Command | Effect |
|---------|--------|
| `tv:on` | Turns on the TV and switches it to Kodi's input |
| `tv:off` | Puts the TV in standby |
| `tv:toggle` | Toggles between on and off |
| `wait:1.5` | Waits for the given number of seconds |
| `kodi:<builtin>` | Runs a Kodi builtin command |
| `shell:<command>` | Runs a system command |
| `45:70:10:00` | Sends a raw CEC frame using the external command from the CEC section |
| `tx:4F:36` | Sends a raw CEC frame through `/dev/cec0` (Linux only) |
| `audio:45:70:10:00` | Requests System Audio Mode: waits for the CEC bus to be free, sends the frame and checks that the audio stays on, retrying for up to 50 seconds (Linux only) |

How a frame is built, using `45:70:10:00` as an example:

| Part | Meaning |
|------|---------|
| `4` | Logical address of Kodi, the sender: it can be 1, 4, 8 or 11 |
| `5` | Logical address of the recipient, here the audio system (`F` = all devices) |
| `70` | Command code, here the System Audio Mode request |
| `10:00` | Physical address of Kodi, here 1.0.0.0 |

#### Examples

Turn on the TV and switch to a specific input:

```
tv:on; wait:5; 4F:82:20:00
```

Turn off the soundbar and TV. The wait is there because `tv:off` right after the soundbar's standby may have no effect:

```
tx:4F:36; wait:8; tv:off
```

Activate the soundbar when a transfer arrives. Use `audio:` rather than a frame with a fixed wait: the TV's wake-up time varies, and a request sent while it is starting can leave the soundbar on but muted.

| Setting | Value |
|---------|-------|
| Receiving → Wait for the TV to turn on | `2` |
| Receiving → Additional commands | `audio:45:70:10:00; wait:2` |
| Sending → Keep playing here after the confirmation | `8` |
| Sending → Commands to turn off the TV | `tx:4F:36; wait:8; tv:off` |

The default external command for raw frames is `echo "tx {frame}" | cec-client -s -d 1`. Availability and syntax depend on the system, so try it over SSH before using it.

### Limitations

- **Files**: network paths must also work on the destination. For local files and recordings, the folder must be shared by Samba on LibreELEC, and the recording must come from Tvheadend installed on that Kodi.
- **Add-ons**: the add-on must also be installed, enabled and signed in on the destination. FollowMe checks that it is installed and enabled, but not the account sign-in. Some add-ons show their own resume dialog or use links that do not work on another device.
- **TV channels**: the destination looks for the channel by ID, name or number, so it must have the same channels.
- **Party mode**: the song and queue carry on, but songs added later are picked from the destination's library, and the listening history is not transferred.
- **CEC**: on Android, raw frames, `tx:` and `audio:` cannot be used; `tv:on`, `tv:off` and `tv:toggle` remain available. With Pulse-Eight USB adapters, `cec-client` may fail to open the adapter while Kodi is using it.

### Security

Kodi stores the settings in plain text, including the other device's password, in `userdata/addon_data/script.followme/settings.xml`. Do not share that file or backups that contain it.

### Troubleshooting

Every step is written to the Kodi log with the prefix `[script.followme]`. The log may contain the addresses of your devices: check it before publishing it.

### License

Copyright © 2026 fabpolli

GPL-3.0: the full text is in [LICENSE.txt](LICENSE.txt).
