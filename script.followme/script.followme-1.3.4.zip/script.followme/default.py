# -*- coding: utf-8 -*-
"""Sender: RunScript(script.followme[,target=<name>]).

Captures what is playing, sends it to the chosen device, waits for confirmation,
then runs steps 5-7 (local TV off, wait, extra commands).
"""
import sys
import time
import uuid

import xbmc
import xbmcgui

from resources.lib import capture, cec, shares
from resources.lib.common import (ADDON_ID, NOTIFY_MESSAGE, SENDING_PROP, STATUS_LABEL,
                                  FollowMeError, RpcError, addon, clear_home_prop,
                                  device_name, get_bool, get_int, get_str, home_prop,
                                  local_rpc, log, notify, tr)
from resources.lib.remote import load_devices

# A running transfer ignores further key presses; older marks are leftovers of a crash
SENDING_MAX_AGE = 600


def parse_args(argv):
    args = {}
    for arg in argv[1:]:
        if '=' in arg:
            key, value = arg.split('=', 1)
            args[key.strip().lower()] = value.strip()
    return args


def choose_device(devices, wanted):
    if wanted:
        for device in devices:
            if wanted.lower() in (device.name.lower(), device.host.lower()):
                return device
    if len(devices) == 1:
        return devices[0]
    index = xbmcgui.Dialog().select(tr(32002), [d.name for d in devices])
    return devices[index] if index >= 0 else None


def missing_addon(device, state):
    """Returns the first add-on the content needs that the device cannot use."""
    for addon_id in capture.required_addons(state):
        try:
            result = device.call('Addons.GetAddonDetails',
                                 {'addonid': addon_id, 'properties': ['enabled']}) or {}
        except RpcError:
            return addon_id  # not installed
        except FollowMeError:
            continue  # the device did not answer: the transfer reports it
        if not result.get('addon', {}).get('enabled'):
            return addon_id
    return None


def wait_for_target(device, followme_id, monitor, timeout):
    progress = xbmcgui.DialogProgressBG()
    progress.create(tr(30000), tr(32004) % device.name)
    start = time.time()
    try:
        while not monitor.abortRequested():
            elapsed = time.time() - start
            if elapsed > timeout:
                return False, tr(32009)
            progress.update(int(min(99, elapsed * 100 / timeout)))
            try:
                labels = device.call('XBMC.GetInfoLabels', {'labels': [STATUS_LABEL]},
                                     timeout=3) or {}
                value = labels.get(STATUS_LABEL, '')
            except FollowMeError:
                value = ''
            if value.startswith(followme_id + '|'):
                status = value[len(followme_id) + 1:]
                if status == 'ok':
                    return True, ''
                if status.startswith('error:'):
                    return False, status[6:]
            monitor.waitForAbort(1)
        return False, 'abort'
    finally:
        progress.close()


def resume_local(playerid, paused_by_us):
    if paused_by_us:
        try:
            capture.set_paused(playerid, False)
        except RpcError:
            pass


def close_to_home(monitor):
    """Stops playback and leaves nothing open: queues, dialogs, windows."""
    player = xbmc.Player()
    player.stop()
    deadline = time.time() + 10
    while player.isPlaying() and time.time() < deadline and not monitor.abortRequested():
        monitor.waitForAbort(0.2)
    for playlistid in (0, 1):
        try:
            local_rpc('Playlist.Clear', {'playlistid': playlistid})
        except RpcError as exc:
            log('Playlist.Clear failed: %s' % exc, xbmc.LOGWARNING)
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('ActivateWindow(Home)')
    monitor.waitForAbort(0.5)


def leave_tv_on(seconds):
    """Asks before turning off. Kodi reports a timeout like the "no" button,
    so "no" is the answer that turns off and only "yes" keeps the TV on.
    """
    if seconds <= 0:
        return False
    return xbmcgui.Dialog().yesno(tr(30000), tr(32015) % seconds, nolabel=tr(32016),
                                  yeslabel=tr(32017), autoclose=seconds * 1000)


def already_sending():
    try:
        return time.time() - float(home_prop(SENDING_PROP) or 0) < SENDING_MAX_AGE
    except ValueError:
        return False


def main():
    if already_sending():
        log('transfer already running: request ignored')
        return
    home_prop(SENDING_PROP, str(time.time()))
    try:
        transfer()
    finally:
        clear_home_prop(SENDING_PROP)


def transfer():
    monitor = xbmc.Monitor()
    args = parse_args(sys.argv)

    devices = load_devices()
    if not devices:
        notify(tr(32001), error=True)
        addon().openSettings()
        return

    playerid, ptype = capture.active_player()
    if playerid is None:
        notify(tr(32000))
        return

    device = choose_device(devices, args.get('target'))
    if device is None:
        return

    try:
        device.call('JSONRPC.Ping')
    except FollowMeError as exc:
        notify('%s (%s)' % (tr(32003) % device.name, exc), error=True)
        return

    item = capture.current_item(playerid)
    paused_by_us = False
    if (get_bool('send_pause', True) and item.get('type') != 'channel'
            and not capture.is_paused(playerid)):
        try:
            capture.set_paused(playerid, True)
            paused_by_us = True
            monitor.waitForAbort(0.3)
        except RpcError:
            pass

    state = capture.capture_state(playerid, ptype, item)
    if not state:
        resume_local(playerid, paused_by_us)
        notify(tr(32000))
        return

    if not shares.localize_state(state, item.get('channel') or ''):
        resume_local(playerid, paused_by_us)
        log('not reachable from %s: %s' % (device.name, state), xbmc.LOGWARNING)
        notify(tr(32014) % (state.get('title') or '?', device.name), error=True)
        return

    missing = missing_addon(device, state)
    if missing:
        resume_local(playerid, paused_by_us)
        log('%s not available on %s' % (missing, device.name), xbmc.LOGWARNING)
        notify(tr(32013) % (missing, device.name), error=True)
        return

    followme_id = uuid.uuid4().hex
    payload = {'id': followme_id, 'from': device_name(), 'state': state}
    log('sending to %s: %s' % (device.name, payload))
    try:
        device.call('JSONRPC.NotifyAll',
                    {'sender': ADDON_ID, 'message': NOTIFY_MESSAGE, 'data': payload})
    except FollowMeError as exc:
        resume_local(playerid, paused_by_us)
        notify(tr(32006) % (device.name, exc), error=True)
        return

    ok, reason = wait_for_target(device, followme_id, monitor,
                                 max(10, get_int('send_timeout', 90)))
    if not ok:
        resume_local(playerid, paused_by_us)
        notify(tr(32006) % (device.name, reason), error=True)
        return

    notify(tr(32005) % device.name)

    # The destination TV may show the picture some seconds after the confirmation
    monitor.waitForAbort(max(0, get_int('send_overlap', 0)))
    if get_bool('send_stop', True):
        close_to_home(monitor)
    if leave_tv_on(get_int('send_ask_off', 10)):
        log('TV left on')
        return

    # 5. local TV off  6. wait  7. extra commands
    cec.run_commands(get_str('send_off_cmds'), monitor)
    wait = get_int('send_wait', 0)
    if wait > 0:
        monitor.waitForAbort(wait)
    cec.run_commands(get_str('send_extra_cmds'), monitor)


if __name__ == '__main__':
    main()
