# -*- coding: utf-8 -*-
"""Runs a command sequence such as "tv:on; wait:3; 45:70:10:00".

Commands are separated by ';':
  tv:on / tv:off / tv:toggle  -> Kodi CEC builtins (CECActivateSource, CECStandby, CECToggleState)
  wait:N                      -> pause N seconds (decimals allowed)
  kodi:<builtin>              -> any Kodi builtin, e.g. kodi:CECActivateSource
  shell:<command>             -> any shell command
  XX:XX:...                   -> raw CEC frame, sent with the command template in the settings
  tx:XX:XX:...                -> raw CEC frame, sent through the kernel device (Linux)
  audio:XX:XX:...             -> System Audio Mode request, checked until the mode stays on (Linux)
"""
import re
import subprocess

import xbmc

from .common import get_str, log

FRAME_RE = re.compile(r'^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2})*$')
ALIASES = {
    'tv:on': 'CECActivateSource',
    'tv:off': 'CECStandby',
    'tv:toggle': 'CECToggleState',
}
DEFAULT_TEMPLATE = 'echo "tx {frame}" | cec-client -s -d 1'


def split_commands(spec):
    return [part.strip() for part in (spec or '').split(';') if part.strip()]


def build_frame_command(frame, template):
    parts = [p.lower() for p in frame.split(':')]
    to = int(parts[0], 16) & 0x0F
    cmd = ('0x' + parts[1]) if len(parts) > 1 else ''
    payload = ':'.join('0x' + p for p in parts[2:])
    cmdspec = ('cmd=' + cmd) if cmd else ''
    if payload:
        cmdspec += ',payload=' + payload
    values = {
        '{frame}': frame.upper(),
        '{to}': str(to),
        '{cmd}': cmd,
        '{payload}': payload,
        '{cmdspec}': cmdspec,
    }
    line = template
    for key, value in values.items():
        line = line.replace(key, value)
    return line


def run_shell(line):
    log('shell: %s' % line)
    try:
        result = subprocess.run(line, shell=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=60)
        output = result.stdout.decode('utf-8', 'replace').strip()
        if result.returncode != 0:
            log('exit %d: %s' % (result.returncode, output[-500:]), xbmc.LOGWARNING)
        elif output:
            log(output[-500:], xbmc.LOGDEBUG)
    except Exception as exc:  # pylint: disable=broad-except
        log('shell failed: %s' % exc, xbmc.LOGERROR)


def run_commands(spec, monitor):
    for command in split_commands(spec):
        if monitor.abortRequested():
            return
        low = command.lower()
        try:
            if low in ALIASES:
                log('builtin: %s' % ALIASES[low])
                xbmc.executebuiltin(ALIASES[low])
            elif low.startswith('wait:'):
                seconds = float(command[5:].strip().replace(',', '.'))
                monitor.waitForAbort(max(0.0, seconds))
            elif low.startswith('kodi:'):
                builtin = command[5:].strip()
                log('builtin: %s' % builtin)
                xbmc.executebuiltin(builtin)
            elif low.startswith('shell:'):
                run_shell(command[6:].strip())
            elif low.startswith('tx:') or low.startswith('audio:'):
                from . import cecdev  # needs fcntl, not available on every platform
                kind, frame = command.split(':', 1)
                frame = frame.strip()
                if not FRAME_RE.match(frame):
                    raise ValueError('invalid frame: %s' % frame)
                log('%s: %s' % (kind.lower(), frame))
                if low.startswith('tx:'):
                    cecdev.send_frame(frame, monitor)
                else:
                    cecdev.enable_audio_mode(frame, monitor)
            elif FRAME_RE.match(command):
                template = get_str('cec_template', DEFAULT_TEMPLATE)
                run_shell(build_frame_command(command, template))
            else:
                log('unknown command ignored: %s' % command, xbmc.LOGWARNING)
        except Exception as exc:  # pylint: disable=broad-except
            log('command "%s" failed: %s' % (command, exc), xbmc.LOGERROR)
