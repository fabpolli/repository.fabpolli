# -*- coding: utf-8 -*-
"""JSON-RPC client for another Kodi over HTTP."""
import base64
import json
import socket
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .common import FollowMeError, RpcError, get_bool, get_int, get_str

MAX_DEVICES = 3


class RemoteKodi(object):
    def __init__(self, name, host, port=8080, username='', password='', timeout=5):
        self.name = name
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.timeout = timeout
        self.url = 'http://%s:%d/jsonrpc' % (host, port)

    def call(self, method, params=None, timeout=None):
        request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
        if params is not None:
            request['params'] = params
        req = Request(self.url, data=json.dumps(request).encode('utf-8'),
                      headers={'Content-Type': 'application/json'})
        if self.username or self.password:
            token = base64.b64encode(
                ('%s:%s' % (self.username, self.password)).encode('utf-8')).decode('ascii')
            req.add_header('Authorization', 'Basic ' + token)
        try:
            with urlopen(req, timeout=timeout or self.timeout) as resp:
                body = json.loads(resp.read().decode('utf-8'))
        except HTTPError as exc:
            if exc.code == 401:
                raise FollowMeError('HTTP 401 (username/password)')
            raise FollowMeError('HTTP %d' % exc.code)
        except (URLError, socket.timeout, OSError, ValueError) as exc:
            raise FollowMeError(str(getattr(exc, 'reason', exc)))
        if 'error' in body:
            raise RpcError(method, body['error'])
        return body.get('result')


def load_devices():
    devices = []
    for index in range(1, MAX_DEVICES + 1):
        prefix = 'dev%d_' % index
        if not get_bool(prefix + 'enabled'):
            continue
        host = get_str(prefix + 'host').strip()
        if not host:
            continue
        devices.append(RemoteKodi(
            name=get_str(prefix + 'name').strip() or host,
            host=host,
            port=get_int(prefix + 'port', 8080),
            username=get_str(prefix + 'user'),
            password=get_str(prefix + 'pass'),
        ))
    return devices
