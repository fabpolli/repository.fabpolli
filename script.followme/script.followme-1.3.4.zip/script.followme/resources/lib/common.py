# -*- coding: utf-8 -*-
"""Shared helpers: settings, logging, notifications, local JSON-RPC."""
import json

import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = 'script.followme'
NOTIFY_MESSAGE = 'followme'

# Home-window properties used for status reporting between devices
STATUS_PROP = ADDON_ID + '.status'
START_PATH_PROP = ADDON_ID + '.startpath'
START_TITLE_PROP = ADDON_ID + '.starttitle'
SENDING_PROP = ADDON_ID + '.sending'
STATUS_LABEL = 'Window(Home).Property(%s)' % STATUS_PROP

HOME_WINDOW_ID = 10000


class FollowMeError(Exception):
    """A user-facing error during a transfer."""


class RpcError(FollowMeError):
    def __init__(self, method, error):
        message = error.get('message', error) if isinstance(error, dict) else error
        FollowMeError.__init__(self, '%s: %s' % (method, message))
        self.error = error


def addon():
    # A fresh instance always reflects the current settings
    return xbmcaddon.Addon(ADDON_ID)


def log(message, level=xbmc.LOGINFO):
    xbmc.log('[%s] %s' % (ADDON_ID, message), level)


def tr(string_id):
    return addon().getLocalizedString(string_id)


def get_str(setting_id, default=''):
    value = addon().getSetting(setting_id)
    return value if value else default


def get_int(setting_id, default=0):
    try:
        return int(float(addon().getSetting(setting_id)))
    except (TypeError, ValueError):
        return default


def get_bool(setting_id, default=False):
    value = (addon().getSetting(setting_id) or '').lower()
    if value in ('true', 'false'):
        return value == 'true'
    return default


def notify(message, error=False, ms=5000):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification(tr(30000), message, icon, ms)


def home_prop(name, value=None):
    window = xbmcgui.Window(HOME_WINDOW_ID)
    if value is None:
        return window.getProperty(name)
    window.setProperty(name, value)
    return value


def clear_home_prop(name):
    xbmcgui.Window(HOME_WINDOW_ID).clearProperty(name)


def set_status(followme_id, status):
    home_prop(STATUS_PROP, '%s|%s' % (followme_id, status))


def local_rpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if 'error' in response:
        raise RpcError(method, response['error'])
    return response.get('result')


def device_name():
    return xbmc.getInfoLabel('System.FriendlyName') or 'Kodi'
