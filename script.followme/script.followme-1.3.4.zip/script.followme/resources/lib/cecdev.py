# -*- coding: utf-8 -*-
"""Sends CEC frames through the Linux kernel device, using the address Kodi already has.

The Kodi API cannot send raw frames and cec-client may fight with Kodi for the adapter.
"""
import errno
import fcntl
import os
import struct
import time

from .common import FollowMeError, log

DEVICE = '/dev/cec0'
CEC_TRANSMIT = (3 << 30) | (56 << 16) | (ord('a') << 8) | 5
CEC_RECEIVE = (3 << 30) | (56 << 16) | (ord('a') << 8) | 6
CEC_S_MODE = (1 << 30) | (4 << 16) | (ord('a') << 8) | 9
CEC_MODE_MONITOR = 0xe << 4
STATUS_OK = 0x01
OPCODE_SET_AUDIO_MODE = 0x72
QUIET_SECONDS = 4
CHECK_SECONDS = 6


def parse_frame(frame):
    return bytes(int(part, 16) for part in frame.split(':'))


def _transmit(device, data):
    msg = bytearray(56)
    struct.pack_into('<I', msg, 16, len(data))
    msg[32:32 + len(data)] = data
    try:
        fcntl.ioctl(device, CEC_TRANSMIT, msg)
    except OSError:
        return False  # ENONET until the adapter is ready, after the TV turns on
    return bool(msg[50] & STATUS_OK)


def _receive(device, timeout_ms):
    msg = bytearray(56)
    struct.pack_into('<I', msg, 20, timeout_ms)
    try:
        fcntl.ioctl(device, CEC_RECEIVE, msg)
    except OSError as exc:
        if exc.errno != errno.ETIMEDOUT:
            time.sleep(timeout_ms / 1000.0)
        return None
    return bytes(msg[32:32 + struct.unpack_from('<I', msg, 16)[0]])


def send_frame(frame, monitor, timeout=11):
    """Sends once: retries only while the frame cannot be delivered, never after."""
    data = parse_frame(frame)
    device = os.open(DEVICE, os.O_RDWR)
    try:
        end = time.time() + timeout
        while time.time() < end and not monitor.abortRequested():
            if _transmit(device, data):
                return
            monitor.waitForAbort(1)
    finally:
        os.close(device)
    raise FollowMeError('CEC frame not delivered: %s' % frame)


def enable_audio_mode(frame, monitor, timeout=50):
    """Sends a System Audio Mode request and checks that the mode stays on.

    The TV takes a variable time to wake up, and a request sent during that time is
    undone by the audio system (5f:72:01 then 5f:72:00, which leaves it muted). So this
    waits for a quiet bus before sending, and tries again if the mode does not stay on.
    """
    data = parse_frame(frame)
    listener = os.open(DEVICE, os.O_RDWR)
    sender = os.open(DEVICE, os.O_RDWR)
    try:
        fcntl.ioctl(listener, CEC_S_MODE, struct.pack('<I', CEC_MODE_MONITOR))
        start = time.time()
        last_frame = start
        sent_at = None
        audio_on = None
        sends = 0
        while time.time() < start + timeout and not monitor.abortRequested():
            received = _receive(listener, 200)
            now = time.time()
            if received:
                last_frame = now
                if len(received) == 3 and received[1] == OPCODE_SET_AUDIO_MODE:
                    audio_on = received[2] == 1
            if sent_at is None:
                if now - last_frame >= QUIET_SECONDS:
                    if _transmit(sender, data):
                        sent_at = now
                        sends += 1
                        audio_on = None
                    else:
                        last_frame = now - QUIET_SECONDS + 1
            elif now - sent_at >= CHECK_SECONDS:
                if audio_on:
                    log('audio mode on: %d send(s), %.1fs' % (sends, now - start))
                    return
                sent_at = None
                last_frame = now
    finally:
        os.close(listener)
        os.close(sender)
    raise FollowMeError('audio mode not confirmed: %d send(s)' % sends)
