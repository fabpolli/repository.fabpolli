# -*- coding: utf-8 -*-
"""Captures what is playing on this device into a transferable state."""
import re

import xbmc

from .common import (START_PATH_PROP, START_TITLE_PROP, RpcError, home_prop,
                     local_rpc, log)

ITEM_FIELDS = ['file', 'title', 'showtitle', 'channel', 'channeltype']
PLAYER_PROPS = ['time', 'speed', 'partymode', 'playlistid', 'position', 'repeat', 'canseek']
PLUGIN_RE = re.compile(r'^plugin://([^/?]+)', re.IGNORECASE)


def active_player():
    for player in local_rpc('Player.GetActivePlayers') or []:
        if player.get('type') in ('video', 'audio'):
            return player['playerid'], player['type']
    return None, None


def current_item(playerid):
    try:
        result = local_rpc('Player.GetItem', {'playerid': playerid, 'properties': ITEM_FIELDS})
    except RpcError:
        result = local_rpc('Player.GetItem', {'playerid': playerid, 'properties': ['file', 'title']})
    return (result or {}).get('item', {}) or {}


def _props(playerid):
    try:
        return local_rpc('Player.GetProperties',
                         {'playerid': playerid, 'properties': PLAYER_PROPS}) or {}
    except RpcError as exc:
        log('Player.GetProperties failed: %s' % exc, xbmc.LOGWARNING)
        return {}


def is_paused(playerid):
    return _props(playerid).get('speed', 1) == 0


def set_paused(playerid, paused):
    local_rpc('Player.PlayPause', {'playerid': playerid, 'play': not paused})


def to_seconds(t):
    if not t:
        return 0.0
    return (t.get('hours', 0) * 3600 + t.get('minutes', 0) * 60
            + t.get('seconds', 0) + t.get('milliseconds', 0) / 1000.0)


def _playlist_files(playlistid):
    if playlistid is None or playlistid < 0:
        return []
    try:
        result = local_rpc('Playlist.GetItems',
                           {'playlistid': playlistid, 'properties': ['file']}) or {}
    except RpcError:
        return []
    return [item.get('file') or '' for item in result.get('items') or []]


def _channel_info(item):
    info = {
        'name': item.get('channel') or item.get('label') or '',
        'type': item.get('channeltype') or 'tv',
        'number': None,
        'uniqueid': None,
    }
    channelid = item.get('id')
    if isinstance(channelid, int) and channelid >= 0:
        try:
            details = local_rpc('PVR.GetChannelDetails', {
                'channelid': channelid,
                'properties': ['channel', 'channelnumber', 'uniqueid', 'channeltype'],
            })['channeldetails']
            info['name'] = details.get('channel') or details.get('label') or info['name']
            info['number'] = details.get('channelnumber')
            info['uniqueid'] = details.get('uniqueid')
            info['type'] = details.get('channeltype') or info['type']
        except (RpcError, KeyError, TypeError) as exc:
            log('channel details unavailable: %s' % exc, xbmc.LOGWARNING)
    return info


def titles_match(a, b):
    a, b = (a or '').strip().lower(), (b or '').strip().lower()
    return bool(a and b) and (a == b or a in b or b in a)


def choose_path(item, playlist_file, title):
    """Prefer the original plugin:// path, so the destination can resolve it itself."""
    stored = home_prop(START_PATH_PROP)
    stored_title = home_prop(START_TITLE_PROP)
    if stored and stored_title and title and not titles_match(stored_title, title):
        stored = ''
    candidates = [item.get('file'), playlist_file,
                  xbmc.getInfoLabel('Player.FilenameAndPath'), stored]
    candidates = [c for c in candidates if c]
    for candidate in candidates:
        if candidate.startswith('plugin://'):
            return candidate
    return candidates[0] if candidates else ''


def required_addons(state):
    """The add-ons the destination needs to open the plugin:// paths of a state."""
    paths = state.get('items') or [state.get('path') or '']
    addon_ids = []
    for path in paths:
        match = PLUGIN_RE.match(path)
        if match and match.group(1) not in addon_ids:
            addon_ids.append(match.group(1))
    return addon_ids


def capture_state(playerid, ptype, item=None):
    item = item if item is not None else current_item(playerid)
    title = item.get('title') or item.get('label') or ''
    media = 'audio' if ptype == 'audio' else 'video'

    if item.get('type') == 'channel':
        channel = _channel_info(item)
        return {'mode': 'channel', 'title': channel['name'] or title, 'channel': channel}

    props = _props(playerid)
    seconds = to_seconds(props.get('time')) if props.get('canseek', True) else 0.0
    playlistid = props.get('playlistid', -1)
    position = props.get('position', -1)
    files = _playlist_files(playlistid)

    if props.get('partymode'):
        queue = [f for f in files[position:] if f] if 0 <= position < len(files) else []
        return {'mode': 'partymode', 'media': 'music' if media == 'audio' else 'video',
                'title': title, 'items': queue, 'time': seconds}

    if len(files) > 1 and 0 <= position < len(files):
        if not files[position]:
            files[position] = choose_path(item, '', title)
        items, new_position = [], 0
        for index, path in enumerate(files):
            if not path:
                continue
            if index == position:
                new_position = len(items)
            items.append(path)
        return {'mode': 'playlist', 'media': media, 'title': title, 'items': items,
                'position': new_position, 'repeat': props.get('repeat', 'off'),
                'playlistid': playlistid, 'time': seconds}

    playlist_file = files[position] if 0 <= position < len(files) else ''
    path = choose_path(item, playlist_file, title)
    if not path:
        return None
    return {'mode': 'file', 'media': media, 'title': title, 'path': path, 'time': seconds}
