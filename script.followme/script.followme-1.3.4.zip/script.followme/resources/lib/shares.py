# -*- coding: utf-8 -*-
"""Turns paths that only exist on this device into URLs the destination can open.

Paths on a NAS, add-on paths and streams are already reachable and stay as they are.
"""
import calendar
import glob
import json
import os
import re
import time

import xbmc
import xbmcvfs

from .common import log

SMB_CONF = '/run/samba/smb.conf'
DVR_LOGS = 'special://profile/addon_data/service.tvheadend*/dvr/log/*'
RECORDING_PREFIX = 'pvr://recordings'
RECORDING_TIME_RE = re.compile(r', (\d{8}_\d{6}), ')
RECORDING_TIME_TOLERANCE = 60


def read_shares(conf=SMB_CONF):
    """Returns {local folder: share name} from the Samba configuration."""
    shares = {}
    name = None
    try:
        with open(conf, errors='replace') as handle:
            for line in handle:
                line = line.strip()
                header = re.match(r'^\[(.+)\]$', line)
                if header:
                    name = header.group(1)
                    continue
                path = re.match(r'^path\s*=\s*(.+)$', line, re.IGNORECASE)
                if path and name and name.lower() != 'global':
                    shares[path.group(1).rstrip('/')] = name
    except OSError as exc:
        log('Samba configuration not readable: %s' % exc, xbmc.LOGWARNING)
    return shares


def share_url(path, shares, address):
    """smb:// URL of a local file, using the deepest share that contains it."""
    for folder in sorted(shares, key=len, reverse=True):
        if address and path.startswith(folder + '/'):
            return 'smb://%s/%s/%s' % (address, shares[folder], path[len(folder) + 1:])
    return None


def recording_file(pvr_path, channel='', logs=None):
    """Local file of a pvr://recordings path, from the Tvheadend recording logs.

    The path holds the UTC start of the recording, without the extra minutes
    the log adds to it.
    """
    match = RECORDING_TIME_RE.search(pvr_path)
    if not match:
        return None
    start = calendar.timegm(time.strptime(match.group(1), '%Y%m%d_%H%M%S'))
    if logs is None:
        logs = glob.glob(xbmcvfs.translatePath(DVR_LOGS))
    found = []
    for name in logs:
        try:
            with open(name, errors='replace') as handle:
                entry = json.load(handle)
            logged = int(entry['start']) - int(entry.get('start_extra') or 0) * 60
        except (OSError, ValueError, KeyError, TypeError):
            continue
        if abs(logged - start) > RECORDING_TIME_TOLERANCE:
            continue
        for item in entry.get('files') or []:
            if os.path.exists(item.get('filename') or ''):
                found.append((entry.get('channelname') == channel, item['filename']))
                break
    found.sort(key=lambda candidate: candidate[0], reverse=True)
    return found[0][1] if found else None


def reachable_url(path, channel='', shares=None):
    """URL of a path as seen from another device, or None if it cannot reach it."""
    if path.startswith(RECORDING_PREFIX):
        path = recording_file(path, channel)
        if not path:
            return None
    elif path.startswith('special://'):
        path = xbmcvfs.translatePath(path)
    if not path.startswith('/'):
        return path
    if shares is None:
        shares = read_shares()
    return share_url(path, shares, xbmc.getIPAddress())


def localize_state(state, channel=''):
    """Rewrites the paths of a state in place. Returns False if one is unreachable."""
    shares = read_shares()
    if state.get('path'):
        url = reachable_url(state['path'], channel, shares)
        if not url:
            return False
        state['path'] = url
    if state.get('items'):
        urls = [reachable_url(path, channel, shares) for path in state['items']]
        if not all(urls):
            return False
        state['items'] = urls
    return True
