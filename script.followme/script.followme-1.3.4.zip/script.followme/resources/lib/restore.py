# -*- coding: utf-8 -*-
"""Starts the received state on this device."""
import time

import xbmc

from .common import FollowMeError, local_rpc, log, tr


def _stop_current(monitor):
    player = xbmc.Player()
    if not player.isPlaying():
        return
    player.stop()
    deadline = time.time() + 10
    while player.isPlaying() and time.time() < deadline and not monitor.abortRequested():
        monitor.waitForAbort(0.2)


def _norm(text):
    return (text or '').strip().lower()


def find_channel(info, channels=None):
    if channels is None:
        group = 'allradio' if info.get('type') == 'radio' else 'alltv'
        result = local_rpc('PVR.GetChannels', {
            'channelgroupid': group,
            'properties': ['channel', 'channelnumber', 'uniqueid'],
        }) or {}
        channels = result.get('channels') or []

    def name_of(ch):
        return _norm(ch.get('channel') or ch.get('label'))

    name, uid, number = _norm(info.get('name')), info.get('uniqueid'), info.get('number')
    rules = [
        lambda ch: uid is not None and ch.get('uniqueid') == uid and name_of(ch) == name,
        lambda ch: bool(name) and name_of(ch) == name,
        lambda ch: uid is not None and ch.get('uniqueid') == uid,
        lambda ch: number is not None and ch.get('channelnumber') == number,
    ]
    for rule in rules:
        for channel in channels:
            if rule(channel):
                return channel.get('channelid')
    return None


def _wait_event(event, monitor, timeout=15):
    deadline = time.time() + timeout
    while not event.is_set() and time.time() < deadline and not monitor.abortRequested():
        monitor.waitForAbort(0.2)


def _start_partymode(state, monitor):
    """Party mode cannot start from a given queue: starts it silently, then moves on to it.

    Kodi then removes the song it picked by itself and keeps adding new ones after the queue.
    """
    media = state.get('media', 'music')
    items = state.get('items') or []
    if not items:
        local_rpc('Player.Open', {'item': {'partymode': media}})
        return
    playerid = 0 if media == 'music' else 1
    av_started = monitor.tracker.av_started
    muted = local_rpc('Application.GetProperties', {'properties': ['muted']})['muted']
    local_rpc('Application.SetMute', {'mute': True})
    try:
        local_rpc('Player.Open', {'item': {'partymode': media}})
        _wait_event(av_started, monitor)
        av_started.clear()
        local_rpc('Playlist.Insert', {'playlistid': playerid, 'position': 1,
                                      'item': [{'file': path} for path in items]})
        local_rpc('Player.GoTo', {'playerid': playerid, 'to': 1})
        _wait_event(av_started, monitor)
    finally:
        local_rpc('Application.SetMute', {'mute': muted})


def start_playback(state, monitor):
    _stop_current(monitor)
    mode = state.get('mode')
    log('starting %s: %s' % (mode, state.get('title', '')))

    if mode == 'channel':
        channel = state.get('channel') or {}
        channelid = find_channel(channel)
        if channelid is None:
            raise FollowMeError(tr(32008) % channel.get('name', '?'))
        local_rpc('Player.Open', {'item': {'channelid': channelid}})

    elif mode == 'partymode':
        _start_partymode(state, monitor)

    elif mode == 'playlist':
        playlistid = state.get('playlistid')
        if playlistid not in (0, 1):
            playlistid = 0 if state.get('media') == 'audio' else 1
        local_rpc('Playlist.Clear', {'playlistid': playlistid})
        local_rpc('Playlist.Add', {'playlistid': playlistid,
                                   'item': [{'file': f} for f in state.get('items', [])]})
        options = {'shuffled': False}
        if state.get('repeat') in ('off', 'one', 'all'):
            options['repeat'] = state['repeat']
        local_rpc('Player.Open', {'item': {'playlistid': playlistid,
                                           'position': state.get('position', 0)},
                                  'options': options})

    elif mode == 'file':
        local_rpc('Player.Open', {'item': {'file': state['path']}})

    else:
        raise FollowMeError('unknown mode: %s' % mode)


def wait_until_playing(monitor, av_started, timeout=60):
    """isPlaying() is already true while the stream opens: waits for onAVStarted."""
    deadline = time.time() + timeout
    while time.time() < deadline and not monitor.abortRequested():
        if av_started.is_set():
            return True
        monitor.waitForAbort(0.5)
    return xbmc.Player().isPlaying()


def seek_to(seconds, monitor, timeout=30):
    """Waits until the stream reports a duration, then seeks."""
    player = xbmc.Player()
    deadline = time.time() + timeout
    while time.time() < deadline and not monitor.abortRequested():
        try:
            if player.isPlaying() and player.getTotalTime() > 0:
                log('seek to %.1fs' % seconds)
                player.seekTime(seconds)
                return True
        except RuntimeError:
            pass
        monitor.waitForAbort(0.5)
    log('seek skipped: no duration available', xbmc.LOGWARNING)
    return False
