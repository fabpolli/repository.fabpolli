# -*- coding: utf-8 -*-
"""Background service: receives transfers and runs steps 1-4 on this device."""
import json
import threading

import xbmc

from resources.lib import cec, restore
from resources.lib.common import (ADDON_ID, NOTIFY_MESSAGE, START_PATH_PROP,
                                  START_TITLE_PROP, FollowMeError, clear_home_prop,
                                  get_bool, get_int, get_str, home_prop, log,
                                  notify, set_status, tr)


class StartTracker(xbmc.Player):
    """Remembers the plugin:// path of the item that was clicked, for add-on content."""

    def __init__(self):
        xbmc.Player.__init__(self)
        self.av_started = threading.Event()

    def onAVStarted(self):  # noqa: N802
        self.av_started.set()

    def onPlayBackStarted(self):  # noqa: N802
        path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
        if path.startswith('plugin://'):
            home_prop(START_PATH_PROP, path)
            home_prop(START_TITLE_PROP,
                      xbmc.getInfoLabel('ListItem.Title') or xbmc.getInfoLabel('ListItem.Label'))
        else:
            self._clear()

    def onPlayBackStopped(self):  # noqa: N802
        self._clear()

    def onPlayBackEnded(self):  # noqa: N802
        self._clear()

    @staticmethod
    def _clear():
        clear_home_prop(START_PATH_PROP)
        clear_home_prop(START_TITLE_PROP)


def receive(payload, monitor):
    followme_id = payload.get('id', '')
    state = payload.get('state') or {}
    set_status(followme_id, 'running')

    message = tr(32007) % payload.get('from', '?')
    if state.get('title'):
        message += ': ' + state['title']
    notify(message)

    # 1. turn on the TV  2. wait  3. extra commands
    cec.run_commands(get_str('recv_on_cmds'), monitor)
    monitor.waitForAbort(max(0, get_int('recv_wait', 8)))
    cec.run_commands(get_str('recv_extra_cmds'), monitor)

    # 4. playback
    monitor.tracker.av_started.clear()
    restore.start_playback(state, monitor)
    if not restore.wait_until_playing(monitor, monitor.tracker.av_started, 60):
        raise FollowMeError(tr(32012))
    log('playback confirmed')

    seconds = float(state.get('time') or 0)
    if (seconds > 1 and state.get('mode') in ('file', 'playlist', 'partymode')
            and get_bool('recv_resume', True)):
        restore.seek_to(max(0.0, seconds - get_int('recv_rewind', 3)), monitor)

    set_status(followme_id, 'ok')


class FollowMeService(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.tracker = StartTracker()
        self.lock = threading.Lock()

    def onNotification(self, sender, method, data):  # noqa: N802
        if sender != ADDON_ID or method.split('.')[-1] != NOTIFY_MESSAGE:
            return
        try:
            payload = json.loads(data)
            if isinstance(payload, str):
                payload = json.loads(payload)
        except ValueError:
            log('invalid payload: %s' % data, xbmc.LOGERROR)
            return
        followme_id = payload.get('id', '')
        if not self.lock.acquire(False):
            set_status(followme_id, 'error:' + tr(32011))
            return
        worker = threading.Thread(target=self._handle, args=(payload,))
        worker.daemon = True
        worker.start()

    def _handle(self, payload):
        try:
            receive(payload, self)
        except Exception as exc:  # pylint: disable=broad-except
            log('transfer failed: %s' % exc, xbmc.LOGERROR)
            set_status(payload.get('id', ''), 'error:%s' % exc)
            notify(str(exc), error=True)
        finally:
            self.lock.release()


if __name__ == '__main__':
    service = FollowMeService()
    log('service started')
    while not service.abortRequested():
        if service.waitForAbort(60):
            break
    log('service stopped')
